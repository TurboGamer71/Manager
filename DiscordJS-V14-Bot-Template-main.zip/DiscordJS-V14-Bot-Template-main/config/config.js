module.exports = {

  Prefix: "?", // YOUR BOT PREFIX.

  Users: {
    OWNERS: ["849413565487382578", "554029264492691476"] // THE BOT OWNERS ID.
  },

  Handlers: {
    MONGO: "" // YOUR MONGO URI. (USE THIS ONLY IN VSCODE)
  },

  Client: {
    TOKEN: "", // YOUR BOT TOKEN. (USE THIS ONLY IN VSCODE)
    ID: "" // YOUR BOT ID.
  }

}
