const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "", // Name of command
    type: 3, // Command type
    run: async (client, interaction, config, db) => {
        // execute

    },
};
