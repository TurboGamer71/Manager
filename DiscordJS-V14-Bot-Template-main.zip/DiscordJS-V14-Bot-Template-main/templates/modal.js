const { EmbedBuilder } = require("discord.js");

module.exports = {
    id: "", // Your modal customId.
    run: async (client, interaction, config, db) => {

        // execute.

    },
};
